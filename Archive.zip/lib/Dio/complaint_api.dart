import 'package:http/http.dart' as http;
import 'dart:convert';
import '../model/complaint_model.dart';

class ComplaintApi {
  static const String baseUrl = 'http://192.168.0.23:3000/api/complaints';

  Future<void> submitComplaint(ComplaintModel complaint) async {
    final response = await http.post(
      Uri.parse(baseUrl),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(complaint.toJson()),
    );

    if (response.statusCode != 200 && response.statusCode != 201) {
      throw Exception('Failed to submit complaint: ${response.body}');
    }
  }
}

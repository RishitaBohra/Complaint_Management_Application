// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'complaint_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ComplaintModel _$ComplaintModelFromJson(Map<String, dynamic> json) =>
    ComplaintModel(
      name: json['name'] as String,
      date: json['date'] as String,
      contact: json['contact'] as String,
      block: json['block'] as String,
      type: json['type'] as String,
      preferredTime: json['preferredTime'] as String,
      description: json['description'] as String,
    );

Map<String, dynamic> _$ComplaintModelToJson(ComplaintModel instance) =>
    <String, dynamic>{
      'name': instance.name,
      'date': instance.date,
      'contact': instance.contact,
      'block': instance.block,
      'type': instance.type,
      'preferredTime': instance.preferredTime,
      'description': instance.description,
    };

import 'package:json_annotation/json_annotation.dart';

part 'complaint_model.g.dart';

@JsonSerializable()
class ComplaintModel {
  final String name;
  final String date;
  final String contact;
  final String block;
  final String type;
  final String preferredTime;
  final String description;

  ComplaintModel({
    required this.name,
    required this.date,
    required this.contact,
    required this.block,
    required this.type,
    required this.preferredTime,
    required this.description,
  });

  factory ComplaintModel.fromJson(Map<String, dynamic> json) =>
      _$ComplaintModelFromJson(json);

  Map<String, dynamic> toJson() => _$ComplaintModelToJson(this);
}

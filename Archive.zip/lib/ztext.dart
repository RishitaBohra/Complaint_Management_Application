// // import 'package:flutter/material.dart';
// // import 'package:flutter_riverpod/flutter_riverpod.dart';
// // import 'package:amity_university/model/complaint_model.dart';
// // import 'package:amity_university/provider/complaint_provider.dart';
// // import 'package:amity_university/Presentation/Constants/ColorPicker.dart';
// // import 'package:amity_university/Presentation/UI/Home/Home.dart';

// // class ComplaintFormScreen extends ConsumerStatefulWidget {
// //   const ComplaintFormScreen({super.key});

// //   @override
// //   ConsumerState<ComplaintFormScreen> createState() => _ComplaintFormScreenState();
// // }

// // class _ComplaintFormScreenState extends ConsumerState<ComplaintFormScreen> {
// //   final _formKey = GlobalKey<FormState>();
// //   final TextEditingController nameController = TextEditingController();
// //   final TextEditingController dateController = TextEditingController();
// //   final TextEditingController contactController = TextEditingController();
// //   final TextEditingController blockController = TextEditingController();
// //   final TextEditingController descriptionController = TextEditingController();

// //   String? selectedComplaintType;
// //   String? preferredTimeCarpentry;
// //   String? preferredTimePlumbing;

// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text("Technical Complaint Registration Form", style: TextStyle(color: Colors.white)),
// //         backgroundColor: ColorPicker.blueColor,
// //         iconTheme: const IconThemeData(color: Colors.white),
// //       ),
// //       body: SafeArea(
// //         child: Padding(
// //           padding: const EdgeInsets.all(12),
// //           child: Form(
// //             key: _formKey,
// //             child: ListView(
// //               children: [
// //                 const Text(
// //                   "Please enter the below details correctly to lodge your maintenance related complaint.\n\n"
// //                   "Note: In case of an emergency, please contact the Maintenance Supervisor directly at "
// //                   "9772764090.",
// //                   style: TextStyle(fontSize: 14),
// //                 ),
// //                 const SizedBox(height: 20),
// //                 _buildTextField("Name *", nameController),
// //                 _buildDatePicker("Date *", dateController),
// //                 _buildTextField("Contact Number *", contactController, isPhone: true),
// //                 _buildTextField("Block/Flat Number *", blockController),
// //                 _buildRadioGroup("Complaint Type *", [
// //                   "Plumbing", "Electrical", "Carpentry", "Civil", "Other"
// //                 ], selectedComplaintType, (value) {
// //                   setState(() {
// //                     selectedComplaintType = value;
// //                   });
// //                 }),
// //                 _buildRadioGroup("Preferred Time for Carpentry/Civil", [
// //                   "09:00 AM to 01:00 PM", "02:00 PM to 05:00 PM"
// //                 ], preferredTimeCarpentry, (value) {
// //                   setState(() {
// //                     preferredTimeCarpentry = value;
// //                   });
// //                 }),
// //                 _buildRadioGroup("Preferred Time for Plumbing and Electrical", [
// //                   "09:00 AM to 01:00 PM", "02:00 PM to 05:00 PM", "05:00 PM to 07:00 PM"
// //                 ], preferredTimePlumbing, (value) {
// //                   setState(() {
// //                     preferredTimePlumbing = value;
// //                   });
// //                 }),
// //                 const SizedBox(height: 12),
// //                 const Text("Description *", style: TextStyle(fontWeight: FontWeight.bold)),
// //                 const SizedBox(height: 5),
// //                 TextFormField(
// //                   controller: descriptionController,
// //                   maxLines: 4,
// //                   validator: (value) => value!.isEmpty ? "Required" : null,
// //                   decoration: InputDecoration(
// //                     hintText: "Enter your answer",
// //                     border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
// //                   ),
// //                 ),
// //                 const SizedBox(height: 20),
// //                 ElevatedButton(
// //                   style: ElevatedButton.styleFrom(
// //                     backgroundColor: Colors.red,
// //                     minimumSize: const Size(double.infinity, 50),
// //                   ),
// //                   onPressed: () {
// //                     if (_formKey.currentState!.validate()) {
// //                       final complaint = ComplaintModel(
// //                         name: nameController.text,
// //                         date: dateController.text,
// //                         contact: contactController.text,
// //                         block: blockController.text,
// //                         type: selectedComplaintType ?? '',
// //                         preferredTime: (selectedComplaintType == "Carpentry" || selectedComplaintType == "Civil")
// //                             ? preferredTimeCarpentry ?? ''
// //                             : preferredTimePlumbing ?? '',
// //                         description: descriptionController.text,
// //                       );

// //                       ref.read(submitComplaintProvider(complaint).future).then((_) {
// //                         ScaffoldMessenger.of(context).showSnackBar(
// //                           const SnackBar(content: Text("Complaint submitted successfully")),
// //                         );
// //                         Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
// //                       }).catchError((error) {
// //                         ScaffoldMessenger.of(context).showSnackBar(
// //                           SnackBar(content: Text("Error: ${error.toString()}")),
// //                         );
// //                       });
// //                     }
// //                   },
// //                   child: const Text("Submit", style: TextStyle(color: Colors.white)),
// //                 ),
// //               ],
// //             ),
// //           ),
// //         ),
// //       ),
// //     );
// //   }

// //   Widget _buildTextField(String label, TextEditingController controller, {bool isPhone = false}) {
// //     return Padding(
// //       padding: const EdgeInsets.symmetric(vertical: 8),
// //       child: TextFormField(
// //         controller: controller,
// //         keyboardType: isPhone ? TextInputType.phone : TextInputType.text,
// //         validator: (value) => value!.isEmpty ? "Required" : null,
// //         decoration: InputDecoration(
// //           labelText: label,
// //           border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
// //         ),
// //       ),
// //     );
// //   }

// //   Widget _buildDatePicker(String label, TextEditingController controller) {
// //     return Padding(
// //       padding: const EdgeInsets.symmetric(vertical: 8),
// //       child: TextFormField(
// //         controller: controller,
// //         readOnly: true,
// //         validator: (value) => value!.isEmpty ? "Required" : null,
// //         decoration: InputDecoration(
// //           labelText: label,
// //           suffixIcon: const Icon(Icons.calendar_today),
// //           border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
// //         ),
// //         onTap: () async {
// //           final pickedDate = await showDatePicker(
// //             context: context,
// //             initialDate: DateTime.now(),
// //             firstDate: DateTime(2020),
// //             lastDate: DateTime(2030),
// //           );
// //           if (pickedDate != null) {
// //             controller.text = "${pickedDate.day.toString().padLeft(2, '0')}-"
// //                               "${pickedDate.month.toString().padLeft(2, '0')}-"
// //                               "${pickedDate.year}";
// //           }
// //         },
// //       ),
// //     );
// //   }

// //   Widget _buildRadioGroup(String title, List<String> options, String? groupValue, Function(String?) onChanged) {
// //     return Column(
// //       crossAxisAlignment: CrossAxisAlignment.start,
// //       children: [
// //         const SizedBox(height: 16),
// //         Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
// //         ...options.map(
// //           (option) => RadioListTile<String>(
// //             value: option,
// //             groupValue: groupValue,
// //             onChanged: onChanged,
// //             title: Text(option),
// //             visualDensity: const VisualDensity(horizontal: 0, vertical: -4),
// //           ),
// //         ),
// //       ],
// //     );
// //   }
// // }
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';

// class ComplaintFormScreen extends StatefulWidget {
//   const ComplaintFormScreen({super.key});

//   @override
//   State<ComplaintFormScreen> createState() => _ComplaintFormScreenState();
// }

// class _ComplaintFormScreenState extends State<ComplaintFormScreen> {
//   final nameController = TextEditingController();
//   final dateController = TextEditingController();
//   final contactController = TextEditingController();
//   final flatController = TextEditingController();
//   final descriptionController = TextEditingController();

//   String? complaintType;
//   String? timeCarpentryCivil;
//   String? timePlumbingElectrical;

//   final complaintOptions = [
//     "Plumbing",
//     "Electrical",
//     "Carpentry",
//     "Civil",
//     "Other"
//   ];

//   final timeSlotsCarpentryCivil = [
//     "09:00 AM to 01:00 PM",
//     "02:00 PM to 05:00 PM"
//   ];

//   final timeSlotsPlumbingElectrical = [
//     "09:00 AM to 01:00 PM",
//     "02:00 PM to 05:00 PM",
//     "05:00 PM to 07:00 PM"
//   ];

//   Future<void> _submitForm() async {
//     final body = {
//       "name": nameController.text,
//       "date": dateController.text,
//       "contact": contactController.text,
//       "block": flatController.text,
//       "complaintType": complaintType ?? "",
//       "timeCarpentryCivil": timeCarpentryCivil ?? "",
//       "timePlumbingElectrical": timePlumbingElectrical ?? "",
//       "description": descriptionController.text,
//       "complaintNumber": "0080", // static for now
//     };

//     try {
//       final response = await http.post(
//         Uri.parse("http://192.168.0.23:3000/api/complaints"),
//         headers: {"Content-Type": "application/json"},
//         body: jsonEncode(body),
//       );

//       print("STATUS: ${response.statusCode}");
//       print("RESPONSE: ${response.body}");

//       final result = jsonDecode(response.body);
//       final status = result['status'] ?? false;
//       final message = result['message'] ?? 'No message';

//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text(status ? "✅ $message" : "❌ $message")),
//       );
//     } catch (e) {
//       print("ERROR: $e");
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text("Error occurred: $e")),
//       );
//     }
//   }

//   Future<void> _pickDate() async {
//     final picked = await showDatePicker(
//       context: context,
//       initialDate: DateTime.now(),
//       firstDate: DateTime(2020),
//       lastDate: DateTime(2030),
//     );
//     if (picked != null) {
//       setState(() {
//         dateController.text = "${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}";
//       });
//     }
//   }

//   Widget buildSectionTitle(String title) => Padding(
//         padding: const EdgeInsets.symmetric(vertical: 12),
//         child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
//       );

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text("Technical Complaint Registration")),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.all(16),
//         child: Column(children: [
//           buildSectionTitle("1. Name *"),
//           TextField(controller: nameController, decoration: const InputDecoration(hintText: "Enter your name")),

//           buildSectionTitle("2. Date *"),
//           TextField(
//             controller: dateController,
//             readOnly: true,
//             onTap: _pickDate,
//             decoration: const InputDecoration(hintText: "dd-mm-yyyy", suffixIcon: Icon(Icons.calendar_today)),
//           ),

//           buildSectionTitle("3. Contact Number *"),
//           TextField(
//             controller: contactController,
//             keyboardType: TextInputType.phone,
//             decoration: const InputDecoration(hintText: "Enter your number"),
//           ),

//           buildSectionTitle("4. Block/Flat Number *"),
//           TextField(controller: flatController, decoration: const InputDecoration(hintText: "Enter your block/flat")),

//           buildSectionTitle("5. Complaint Type *"),
//           ...complaintOptions.map((type) => RadioListTile(
//                 title: Text(type),
//                 value: type,
//                 groupValue: complaintType,
//                 onChanged: (val) => setState(() => complaintType = val),
//               )),

//           buildSectionTitle("6. Preferred Time for Carpentry/Civil"),
//           ...timeSlotsCarpentryCivil.map((slot) => RadioListTile(
//                 title: Text(slot),
//                 value: slot,
//                 groupValue: timeCarpentryCivil,
//                 onChanged: (val) => setState(() => timeCarpentryCivil = val),
//               )),

//           buildSectionTitle("7. Preferred Time for Plumbing and Electrical"),
//           ...timeSlotsPlumbingElectrical.map((slot) => RadioListTile(
//                 title: Text(slot),
//                 value: slot,
//                 groupValue: timePlumbingElectrical,
//                 onChanged: (val) => setState(() => timePlumbingElectrical = val),
//               )),

//           buildSectionTitle("8. Description *"),
//           TextField(
//             controller: descriptionController,
//             maxLines: 4,
//             decoration: const InputDecoration(
//               hintText: "Enter your complaint details",
//               border: OutlineInputBorder(),
//             ),
//           ),

//           const SizedBox(height: 24),
//           ElevatedButton(
//             style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
//             onPressed: _submitForm,
//             child: const Padding(
//               padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
//               child: Text("Submit", style: TextStyle(fontSize: 16)),
//             ),
//           ),
//         ]),
//       ),
//     );
//   }
// }
// complaint_form_emulator.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ComplaintFormScreen extends StatefulWidget {
  const ComplaintFormScreen({super.key});

  @override
  State<ComplaintFormScreen> createState() => _ComplaintFormScreenState();
}

class _ComplaintFormScreenState extends State<ComplaintFormScreen> {
  final nameController = TextEditingController();
  final dateController = TextEditingController();
  final contactController = TextEditingController();
  final flatController = TextEditingController();
  final descriptionController = TextEditingController();

  String? complaintType;
  String? timeCarpentryCivil;
  String? timePlumbingElectrical;

  final complaintOptions = ["Plumbing", "Electrical", "Carpentry", "Civil", "Other"];
  final timeSlotsCarpentryCivil = ["09:00 AM to 01:00 PM", "02:00 PM to 05:00 PM"];
  final timeSlotsPlumbingElectrical = ["09:00 AM to 01:00 PM", "02:00 PM to 05:00 PM", "05:00 PM to 07:00 PM"];

  Future<void> _submitForm() async {
    final body = {
      "name": nameController.text,
      "date": dateController.text,
      "contact": contactController.text,
      "block": flatController.text,
      "complaintType": complaintType ?? "",
      "timeCarpentryCivil": timeCarpentryCivil ?? "",
      "timePlumbingElectrical": timePlumbingElectrical ?? "",
      "description": descriptionController.text,
      "complaintNumber": "0080",
    };

    try {
      final response = await http.post(
        Uri.parse("http://10.0.2.2:3000/api/complaints"), // ← Emulator IP
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(body),
      );

      print("STATUS: ${response.statusCode}");
      print("RESPONSE: ${response.body}");

      final result = jsonDecode(response.body);
      final status = result['status'] ?? false;
      final message = result['message'] ?? 'No message';

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(status ? "✅ $message" : "❌ $message")),
      );
    } catch (e) {
      print("ERROR: $e");
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (picked != null) {
      dateController.text =
          "${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}";
    }
  }

  Widget buildSectionTitle(String title) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Complaint Registration Form")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          buildSectionTitle("1. Name *"),
          TextField(controller: nameController, decoration: const InputDecoration(hintText: "Enter your name")),

          buildSectionTitle("2. Date *"),
          TextField(
            controller: dateController,
            readOnly: true,
            onTap: _pickDate,
            decoration: const InputDecoration(hintText: "dd-mm-yyyy", suffixIcon: Icon(Icons.calendar_today)),
          ),

          buildSectionTitle("3. Contact Number *"),
          TextField(controller: contactController, keyboardType: TextInputType.phone),

          buildSectionTitle("4. Block/Flat Number *"),
          TextField(controller: flatController),

          buildSectionTitle("5. Complaint Type *"),
          ...complaintOptions.map((type) => RadioListTile(
                title: Text(type),
                value: type,
                groupValue: complaintType,
                onChanged: (val) => setState(() => complaintType = val),
              )),

          buildSectionTitle("6. Preferred Time for Carpentry/Civil"),
          ...timeSlotsCarpentryCivil.map((slot) => RadioListTile(
                title: Text(slot),
                value: slot,
                groupValue: timeCarpentryCivil,
                onChanged: (val) => setState(() => timeCarpentryCivil = val),
              )),

          buildSectionTitle("7. Preferred Time for Plumbing and Electrical"),
          ...timeSlotsPlumbingElectrical.map((slot) => RadioListTile(
                title: Text(slot),
                value: slot,
                groupValue: timePlumbingElectrical,
                onChanged: (val) => setState(() => timePlumbingElectrical = val),
              )),

          buildSectionTitle("8. Description *"),
          TextField(
            controller: descriptionController,
            maxLines: 4,
            decoration: const InputDecoration(border: OutlineInputBorder(), hintText: "Enter your complaint"),
          ),

          const SizedBox(height: 20),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            onPressed: _submitForm,
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
              child: Text("Submit", style: TextStyle(fontSize: 16)),
            ),
          )
        ]),
      ),
    );
  }
}

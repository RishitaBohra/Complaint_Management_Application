
import 'package:amity_university/Presentation/Constants/ColorPicker.dart';
import 'package:amity_university/Presentation/UI/Auth%20File/LoginScreen.dart';
import 'package:amity_university/Presentation/UI/Auth%20File/OTPScreen.dart';
import 'package:amity_university/Presentation/UI/Auth%20File/OnBoarding.dart';
import 'package:amity_university/Presentation/UI/Home/Form.dart' hide ComplaintFormScreen;
import 'package:amity_university/Presentation/UI/Home/Home.dart';
import 'package:amity_university/Presentation/UI/Home/Notifications.dart';
import 'package:amity_university/Presentation/UI/Home/Viewdetails.dart';
import 'package:amity_university/Presentation/UI/Home/plan.dart';
import 'package:amity_university/Presentation/UI/Home/profile.dart';
import 'package:amity_university/Presentation/UI/Home/view.dart';
import 'package:amity_university/Presentation/UI/SplashScreen.dart';
import 'package:amity_university/ztext.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';



void main() {
  runApp(
    ProviderScope(
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Complaint App ',
      theme: ThemeData(
        
        colorScheme: ColorScheme.fromSeed(seedColor: ColorPicker.blueColor),
      ),
      home:  ComplaintFormScreen(),

    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      appBar: AppBar(
       
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        
        title: Text(widget.title),
      ),
      body: Center(
        
        child: Column(
         
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text('You have pushed the button this many times:'),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ), 
    );
  }
}

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../Dio/complaint_api.dart';
import '../model/complaint_model.dart';

final complaintApiProvider = Provider((ref) => ComplaintApi());

final submitComplaintProvider = FutureProvider.family<void, ComplaintModel>((ref, complaint) async {
  final api = ref.read(complaintApiProvider);
  await api.submitComplaint(complaint);
});

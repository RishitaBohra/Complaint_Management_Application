import 'package:amity_university/Presentation/UI/Home/Notifications.dart';
import 'package:amity_university/Presentation/UI/Home/Viewdetails.dart';
import 'package:amity_university/Presentation/UI/Home/plan.dart';
import 'package:amity_university/Presentation/UI/Home/profile.dart';
import 'package:amity_university/Presentation/UI/Home/view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:amity_university/Presentation/Constants/ColorPicker.dart';
import 'package:amity_university/Presentation/UI/Home/Form.dart';

import 'package:cycle_banner/cycle_banner.dart';


class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final List<String> complaintTypes = [
    "Maintenance",
    
    "Electricity Issue",
  ];

final List<String> images = [
  'assets/logo.png',
  'assets/logo.png',
  'assets/logo.png',
];






  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: ColorPicker.blueColor,
        title: Row(
          children: [
            GestureDetector(
             onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const ProfileScreen()),
    );
  },
              child: const CircleAvatar(
                backgroundImage: AssetImage('assets/logo.png'),
                radius: 18,
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Vivek Goyal", style: TextStyle(fontSize: 16, color: Colors.white)),
                GestureDetector(
                  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const PlanScreen()),
    );
  },
                  
                  
                  child: Text("Free Plan", style: TextStyle(fontSize: 12, color: Colors.white70))),
              ],
            ),
            const Spacer(),
            GestureDetector(
              onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const NotificationScreen()),
    );
  },
              
              child: const Icon(Icons.notifications, color: Colors.white)),
          ],
        ),
      ),

      body: SingleChildScrollView(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              children: [


             CycleBanner(
  images,
  (BuildContext context, int index) {
    return Image.asset(
      images[index % images.length],
      width: double.infinity,
      fit: BoxFit.cover,
    );
  },
),



                // Banner image
                // Container(
                //   height: 150,
                //   width: double.infinity,
                //   decoration: const BoxDecoration(
                //     image: DecorationImage(
                //       image: AssetImage('assets/logo.png'),
                //       fit: BoxFit.cover,
                //     ),
                //   ),
                // ),

                const SizedBox(height: 10),

                // Grid buttons
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.2,
                  children: [
                    GestureDetector(
                      onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const ComplaintFormScreen()),
    );
  },
                      child: Card(
                        color: ColorPicker.blueColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 2,
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: const [
                              Icon(Icons.folder, size: 30, color: Colors.white),
                              SizedBox(height: 8),
                              Text(
                                'Add Complaint',
                                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                   
                  
                      onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const ViewComplaints()),
    );
  },

                      child: Card(
                        color: ColorPicker.blueColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 2,
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [ 
                      
                           
                              Icon(Icons.remove_red_eye_outlined, size: 30, color: Colors.white),
                              SizedBox(height: 8),
                              Text(
                                'View Complaint',
                                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                // Recent Complaints Title
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    children: [
                      const Text(
                        "Recent Complaints",
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                       Spacer(),

                      // Text(
                      //   "View All",
                        
                      //   style: TextStyle(color: ColorPicker.blueColor),
                      // ),

                     GestureDetector(
  onTap: () {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ViewComplaints()));
  },
  child: Text(
    "View All",
    style: TextStyle(color: ColorPicker.blueColor, fontWeight: FontWeight.w500),
  ),
),



                    ],
                  ),
                ),

                const SizedBox(height: 10),

                // Complaint Cards
                ListView.builder(
                  itemCount: complaintTypes.length,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return _buildComplaintCard(complaintTypes[index]);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildComplaintCard(String type) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 8),
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: ColorPicker.yellowColor,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      "Complaint",
                      style: TextStyle(fontSize: 12, color: ColorPicker.blueColor),
                    ),
                  ),
                  const Spacer(),
                  Row(
                    children: const [
                      Icon(Icons.calendar_today, size: 16, color: ColorPicker.blueColor),
                      SizedBox(width: 5),
                      Text("22 June 2025", style: TextStyle(color: ColorPicker.blueColor)),
                    ],
                  ),
                ],
              ),
              const Divider(),
              _buildRow(Icons.person, "Student:", "Vivek Goyal"),
              _buildRow(Icons.report_problem, "Type:", type),
              _buildRow(Icons.location_on, "Location:", "Hostel Block A"),
              _buildRow(Icons.info_outline, "Status:", "Pending"),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                   
                  },
                  child: GestureDetector(
                    onTap: () {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ViewDetails()));
  },
                    child: const Text(
                      "View Details",
                      style: TextStyle(color: ColorPicker.blueColor),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 18, color: Colors.grey),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500)),
          const SizedBox(width: 5),
          Text(value),
        ],
      ),
    );
  }
}

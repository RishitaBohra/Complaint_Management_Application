import 'package:amity_university/Presentation/Constants/ColorPicker.dart';
import 'package:amity_university/Presentation/UI/Home/Home.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:amity_university/model/complaint_model.dart';
import 'package:amity_university/provider/complaint_provider.dart';


class ComplaintFormScreen extends ConsumerStatefulWidget {
  const ComplaintFormScreen({super.key});

  @override
  ConsumerState<ComplaintFormScreen> createState() => _ComplaintFormScreenState();
}

class _ComplaintFormScreenState extends ConsumerState<ComplaintFormScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  final TextEditingController contactController = TextEditingController();
  final TextEditingController blockController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  String? selectedComplaintType;
  String? preferredTimeCarpentry;
  String? preferredTimePlumbing;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Technical Complaint Registration Form",
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
        backgroundColor: ColorPicker.blueColor,
        iconTheme:  IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
               Text(
                "Please enter the below details correctly to lodge your maintenance related complaint.",
              ),
              const SizedBox(height: 8),
              RichText(
                text: TextSpan(
                  text: "Note: In case of an emergency, contact ",
                  style:  TextStyle(color: Colors.black),
                  children: [
                    TextSpan(
                      text: "Maintenance Supervisor ",
                      style:  TextStyle(
                        fontWeight: FontWeight.bold,
                        color: ColorPicker.blueColor,
                      ),
                    ),
                     TextSpan(
                      text: "at ",
                      style: TextStyle(color: Colors.black),
                    ),
                     TextSpan(
                      text: "9772764090",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: ColorPicker.blueColor,
                      ),
                    ),
                  ],
                ),
              ),
               SizedBox(height: 20),
              _buildTextField("Name *", nameController),
              _buildDatePicker("Date *", dateController),
              _buildTextField("Contact Number *", contactController, isPhone: true),
              _buildTextField("Block/Flat Number *", blockController),
               SizedBox(height: 16),
               Text("Complaint Type *", style: TextStyle(fontWeight: FontWeight.bold)),
              ...["Plumbing", "Electrical", "Carpentry", "Civil", "Other"].map(
                (type) => Theme(
                  data: ThemeData(visualDensity: VisualDensity(horizontal: 0, vertical: -4)),
                  child: RadioListTile<String>(
                    value: type,
                    groupValue: selectedComplaintType,
                    onChanged: (value) {
                      setState(() {
                        selectedComplaintType = value!;
                      });
                    },
                    title: Text(type),
                  ),
                ),
              ),
               SizedBox(height: 12),
               Text("Preferred Time for Carpentry/Civil", style: TextStyle(fontWeight: FontWeight.bold)),
              ...["09:00 AM to 01:00 PM", "02:00 PM to 05:00 PM"].map(
                (time) => Theme(
                  data: ThemeData(visualDensity: VisualDensity(horizontal: 0, vertical: -4)),
                  child: RadioListTile<String>(
                    value: time,
                    groupValue: preferredTimeCarpentry,
                    onChanged: (value) {
                      setState(() {
                        preferredTimeCarpentry = value!;
                      });
                    },
                    title: Text(time),
                  ),
                ),
              ),
               SizedBox(height: 12),
               Text("Preferred Time for Plumbing and Electrical", style: TextStyle(fontWeight: FontWeight.bold)),
              ...["09:00 AM to 01:00 PM", "02:00 PM to 05:00 PM", "05:00 PM to 07:00 PM"].map(
                (time) => Theme(
                  data: ThemeData(visualDensity: VisualDensity(horizontal: 0, vertical: -4)),
                  child: RadioListTile<String>(
                    value: time,
                    groupValue: preferredTimePlumbing,
                    onChanged: (value) {
                      setState(() {
                        preferredTimePlumbing = value!;
                      });
                    },
                    title: Text(time),
                  ),
                ),
              ),
               SizedBox(height: 12),
               Text("Description *", style: TextStyle(fontWeight: FontWeight.bold)),
               SizedBox(height: 5),
              TextField(
                controller: descriptionController,
                maxLines: 4,
                decoration: InputDecoration(
                  hintText: "Enter Description",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
               SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: ColorPicker.blueColor,
                  minimumSize: const Size(double.infinity, 50),
                ),
                onPressed: () {
  final complaint = ComplaintModel(
    name: nameController.text,
    date: dateController.text,
    contact: contactController.text,
    block: blockController.text,
    type: selectedComplaintType ?? '',
    preferredTime: (selectedComplaintType == "Carpentry" || selectedComplaintType == "Civil")
        ? preferredTimeCarpentry ?? ''
        : preferredTimePlumbing ?? '',
    description: descriptionController.text,
  );

  ref.read(submitComplaintProvider(complaint).future).then((_) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Complaint submitted successfully!")),
    );
    Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
  }).catchError((error) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Error: ${error.toString()}")),
    );
  });
},

                child:  Text(
                  "Submit",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, {bool isPhone = false}) {
    final String cleanLabel = label.replaceAll('*', '').trim();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        TextField(
          controller: controller,
          keyboardType: isPhone ? TextInputType.number : TextInputType.text,
          maxLength: isPhone ? 10 : null,
          decoration: InputDecoration(
            hintText: "Enter $cleanLabel",
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
         SizedBox(height: 15),
      ],
    );
  }

  Widget _buildDatePicker(String label, TextEditingController controller) {
    final String cleanLabel = label.replaceAll('*', '').trim();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        TextField(
          controller: controller,
          readOnly: true,
          onTap: () async {
            final picked = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime(2020),
              lastDate: DateTime(2030),
            );
            if (picked != null) {
              controller.text = "${picked.day.toString().padLeft(2, '0')}-${picked.month.toString().padLeft(2, '0')}-${picked.year}";
            }
          },
          decoration: InputDecoration(
            hintText: "Enter $cleanLabel",
            suffixIcon: const Icon(Icons.calendar_today),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
        const SizedBox(height: 15),
      ],
    );
  }
}



//   void _submitForm() async {
//     if (nameController.text.isEmpty ||
//         dateController.text.isEmpty ||
//         contactController.text.isEmpty ||
//         blockController.text.isEmpty ||
//         selectedComplaintType == null ||
//         descriptionController.text.isEmpty) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text("Please fill all required fields.")),
//       );
//       return;
//     }

//     try {


//       final response = await http.post(
//   Uri.parse("http://192.168.0.23:3000/api/complaints"), 
//   headers: {"Content-Type": "application/json"},
//   body: jsonEncode({
//     "name": nameController.text,
//     "date": dateController.text,
//     "contact": contactController.text,
//     "block": blockController.text,
//     "complaintType": selectedComplaintType,
//     "preferredTimeCarpentry": preferredTimeCarpentry,
//     "preferredTimePlumbing": preferredTimePlumbing,
//     "description": descriptionController.text,
//   }),
// );
      
//       if (response.statusCode == 200 ) {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text("Complaint submitted successfully!")),
//         );
//         _clearForm();
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(content: Text("Failed to submit: ${response.reasonPhrase}")),
//         );
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text("Error: $e")),
//       );
//     }
//   }

//   void _clearForm() {
//     nameController.clear();
//     dateController.clear();
//     contactController.clear();
//     blockController.clear();
//     descriptionController.clear();
//     setState(() {
//       selectedComplaintType = null;
//       preferredTimeCarpentry = null;
//       preferredTimePlumbing = null;
//     });
//   }
// }
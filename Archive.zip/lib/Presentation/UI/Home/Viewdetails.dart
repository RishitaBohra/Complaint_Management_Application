import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:amity_university/Presentation/Constants/ColorPicker.dart';

class ViewDetails extends ConsumerStatefulWidget {
  const ViewDetails({super.key});

  @override
  ConsumerState<ViewDetails> createState() => _ViewDetailsState();
}

class _ViewDetailsState extends ConsumerState<ViewDetails> {
  @override
  Widget build(BuildContext context) {
   
    final String complaintDateTime = '24 June 2025, 10:30 AM';

    return Scaffold(
      appBar: AppBar(
        backgroundColor: ColorPicker.blueColor,
        title: const Text('Complaint Details', style: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Complaint Title:',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const Text('Water Leakage in Hostel Bathroom'),

            const SizedBox(height: 16),

            const Text(
              'Description:',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const Text('There is continuous water leakage in the bathroom of Block A, Room 101.'),

            const SizedBox(height: 16),

            const Text(
              'Status:',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const Text('Pending'),

            const SizedBox(height: 16),

            const Text(
              'Date & Time:',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            Text(complaintDateTime),
          ],
        ),
      ),
    );
  }
}


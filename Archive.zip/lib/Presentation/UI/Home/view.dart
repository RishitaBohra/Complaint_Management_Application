import 'package:amity_university/Presentation/UI/Home/Viewdetails.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:amity_university/Presentation/Constants/ColorPicker.dart';

class Complaint {
  final String studentName;
  final String type;
  final String location;
  final String status;
  final String date;

  Complaint({
    required this.studentName,
    required this.type,
    required this.location,
    required this.status,
    required this.date,
  });
}

class ViewComplaints extends ConsumerStatefulWidget {
  const ViewComplaints({super.key});

  @override
  ConsumerState<ViewComplaints> createState() => _ViewComplaintsState();
}

class _ViewComplaintsState extends ConsumerState<ViewComplaints> {
  final List<Complaint> complaints = [
    Complaint(
      studentName: "Vivek Goyal",
      type: "Maintenance",
      location: "Hostel Block A",
      status: "Pending",
      date: "22 June 2025",
    ),
    Complaint(
      studentName: "Vivek Goyal",
      type: "Cleaning",
      location: "Hostel Block B",
      status: "Resolved",
      date: "20 June 2025",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Complaints", style: TextStyle(color: Colors.white),),
        backgroundColor: ColorPicker.blueColor,
        iconTheme: const IconThemeData(color: Colors.white), 
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: complaints.length,
        itemBuilder: (context, index) {
          final complaint = complaints[index];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            elevation: 4,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text("Complaint", style: TextStyle(color: ColorPicker.blueColor, fontWeight: FontWeight.bold)),
                    const Spacer(),
                      Text(" ${complaint.date}", style: const TextStyle(color: ColorPicker.blueColor)),
                    ],
                  ),
                 Divider(height: 10,),
                  const SizedBox(height: 8),
                  Text("👤 Student: ${complaint.studentName}"),
                  
                  Text("⚠️ Type: ${complaint.type}"),
                  Text("📍 Location: ${complaint.location}"),
                  Text("ℹ️ Status: ${complaint.status}"),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ViewDetails()),
    );
                        
                      },
                      child: const Text("View Details", style: TextStyle(color: ColorPicker.blueColor)),
                    ),
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

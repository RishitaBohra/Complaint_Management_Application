import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:amity_university/Presentation/Constants/ColorPicker.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Profile", style: TextStyle(color: Colors.white)),
        backgroundColor: ColorPicker.blueColor,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              const CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage('assets/profile.png'), 
              ),
              const SizedBox(height: 16),
              const Text(
                "Vivek Goyal",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                "vivek.goyal@example.com",
                style: TextStyle(color: Colors.grey),
              ),
              const Divider(height: 40),
              _buildProfileItem(Icons.phone, "Phone", "9772764090"),
              _buildProfileItem(Icons.home, "Address", "Hostel Block A"),
              _buildProfileItem(Icons.settings, "Plan", "Free Plan"),
              const SizedBox(height: 30),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: ColorPicker.blueColor,
                  minimumSize: const Size(double.infinity, 50),
                ),
                onPressed: () {
                  
                },
                child: const Text("Edit Profile", style: TextStyle(color: Colors.white)),
              ),
              SizedBox(height: 20,),
              
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileItem(IconData icon, String title, String value) {
    return ListTile(
      leading: Icon(icon, color: ColorPicker.blueColor),
      title: Text(title),
      subtitle: Text(value),
    );
  }
}

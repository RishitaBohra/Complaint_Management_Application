import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:amity_university/Presentation/Constants/ColorPicker.dart';

class NotificationScreen extends ConsumerStatefulWidget {
  const NotificationScreen({super.key});

  @override
  ConsumerState<NotificationScreen> createState() => _NotificationScreenState();
}


class _NotificationScreenState extends ConsumerState<NotificationScreen> {
  final List<Map<String, String>> notifications = [
    {
      "title": "Complaint Received",
      "message": "Your maintenance complaint has been received.",
      "time": "10:30 AM",
    },
    {
      "title": "Complaint In Progress",
      "message": "Your complaint is being addressed by our team.",
      "time": "12:00 PM",
    },
    {
      "title": "Resolved",
      "message": "Your complaint has been resolved. Please provide feedback.",
      "time": "3:45 PM",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Notifications", style: TextStyle(color: Colors.white)),
        backgroundColor: ColorPicker.blueColor,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: ListView.separated(
        itemCount: notifications.length,
        padding: const EdgeInsets.all(10),
        separatorBuilder: (context, index) => const Divider(),
        itemBuilder: (context, index) {
          final notification = notifications[index];
          return ListTile(
            leading: const Icon(Icons.notifications, color: ColorPicker.blueColor),
            title: Text(
              notification["title"]!,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(notification["message"]!),
            trailing: Text(
              notification["time"]!,
              style: const TextStyle(color: Colors.grey, fontSize: 12),
            ),
          );
        },
      ),
    );
  }
}

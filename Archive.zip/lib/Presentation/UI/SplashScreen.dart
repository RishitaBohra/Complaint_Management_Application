import 'package:amity_university/Presentation/UI/Auth%20File/LoginScreen.dart';
import 'package:amity_university/Presentation/UI/Auth%20File/OnBoarding.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  @override
  Widget build(BuildContext context) {
    return AnimatedSplashScreen(
      duration: 3000,
      splash: Image.asset('assets/logo.png', height: 400),
      nextScreen: OnBordingScreen(),
      splashTransition: SplashTransition.fadeTransition,
      backgroundColor: const Color(0xff264c65),
    );
  }
}

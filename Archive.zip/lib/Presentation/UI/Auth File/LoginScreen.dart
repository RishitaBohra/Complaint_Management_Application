import 'package:amity_university/Presentation/Constants/ColorPicker.dart';
import 'package:amity_university/Presentation/UI/Auth%20File/OTPScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class Loginscreen extends ConsumerStatefulWidget {
  const Loginscreen({super.key});

  @override
  ConsumerState<Loginscreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<Loginscreen> {
  final TextEditingController phoneController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, 
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Image.asset('assets/logo.png', height: 100),

                  const SizedBox(height: 10),

                  Text(
                    "Login with Mobile Number",
                    style: TextStyle(
                      fontSize: 20,
                      color: ColorPicker.logheadColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 30),

                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text("Mobile Number"),
                  ),

                  const SizedBox(height: 8),

                  TextField(
                    controller: phoneController,
                    maxLength: 10,
                    keyboardType: TextInputType.phone,
                    style: const TextStyle(fontSize: 14),
                    decoration: InputDecoration(
                      hintText: "Enter mobile number",
                      hintStyle: const TextStyle(fontSize: 13),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        vertical: 12,
                        horizontal: 10,
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: ColorPicker.logheadColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      onPressed: () {
                        if (phoneController.text.length == 10) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>  OTPScreen(otp: phoneController.text,),
                            ),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                "Please enter a valid 10-digit number",
                              ),
                            ),
                          );
                        }
                      },
                      child: const Text(
                        "GENERATE PIN",
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    "By continuing, you have read and agree to the",
                    style: TextStyle(color: Colors.black, fontSize: 12),
                  ),

                  const SizedBox(height: 6),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Privacy Policy",
                        style: TextStyle(
                          color: ColorPicker.pricavyndtermsColor,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(width: 5),
                      const Text("and", style: TextStyle(color: Colors.black)),
                      const SizedBox(width: 5),
                      Text(
                        "Terms of Use",
                        style: TextStyle(
                          color: ColorPicker.pricavyndtermsColor,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

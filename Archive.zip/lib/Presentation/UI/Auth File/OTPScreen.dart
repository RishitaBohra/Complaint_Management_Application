
import 'package:amity_university/Presentation/Constants/ColorPicker.dart';
import 'package:amity_university/Presentation/UI/Home/Home.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';

class OTPScreen extends ConsumerStatefulWidget {
  final String otp;
  const OTPScreen( {super.key, required this.otp,});

  @override
  ConsumerState<OTPScreen> createState() => _OTPScreenState();
}

class _OTPScreenState extends ConsumerState<OTPScreen> {
  String enteredCode = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              Text(
                "Login with Mobile Number",
                style: TextStyle(
                  fontSize: 20,
                  color: ColorPicker.logheadColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 30),
              Container(
                decoration: BoxDecoration(
                  color: ColorPicker.otpsentColorr,
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.all(8),
                child:  Text(
                  "PIN sent on mobile number ${widget.otp}",
                  style: TextStyle(
                    color: ColorPicker.otpsenttextColorr,
                    fontSize: 10,
                  ),
                ),
              ),
              const SizedBox(height: 30),
              OtpTextField(
                numberOfFields: 4,
                borderColor: const Color(0xFF512DA8),
                showFieldAsBox: true,
                onSubmit: (String code) {
                  setState(() {
                    enteredCode = code;
                  });
                },
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ColorPicker.logheadColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onPressed: () {
                    if (enteredCode.length == 4) {
                      Navigator.pushReplacement(
                       context,
                      MaterialPageRoute(
                          builder: (_) => const HomeScreen(),
                         ),
                      );
                    } 
                    // else {
                  //     ScaffoldMessenger.of(context).showSnackBar(
                  //       const SnackBar(
                  //         content: Text("Please enter a valid 4-digit code"),
                  //       ),
                  //     );
                  //   }
                   },
                  child: const Text(
                    "Verify Mobile",
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
